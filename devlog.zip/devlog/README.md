# DevLog 📓

A simple, lightweight command-line journal/habit tracker for developers.
Log your daily work, bugs fixed, and learnings in seconds — no external
dependencies, no server, just local markdown files.

## Features

- `devlog add "message" --tag bugfix` — log an entry with optional tags
- `devlog list --days 7` — view recent entries
- `devlog search "keyword"` — search past entries
- `devlog summary --days 7 --export summary.md` — generate a weekly recap,
  grouped by tag and by day, optionally exported to markdown

Entries are stored as plain markdown files under `~/.devlog/entries/`,
one file per day — easy to read, back up, or version-control yourself.

## Installation

```bash
git clone https://github.com/<your-username>/devlog.git
cd devlog
pip install -e .
```

## Usage

```bash
devlog add "Fixed the login bug" --tag bugfix
devlog add "Refactored the auth module" --tag refactor
devlog list --days 7
devlog search "auth"
devlog summary --days 7
```

## Running tests

```bash
python3 -m unittest discover -s tests -v
```

## Pushing this to GitHub

1. Create a new repository on GitHub (e.g. `devlog`), don't initialize it
   with a README (this project already has one).
2. From this project folder, run:

```bash
git init
git add .
git commit -m "Initial commit: devlog CLI"
git branch -M main
git remote add origin https://github.com/<your-username>/devlog.git
git push -u origin main
```

## Roadmap ideas

- Web dashboard to visualize entries over time
- GitHub Actions integration (auto-log commits/PRs)
- Export to PDF
- Config file for custom log directory

## License

MIT
