import shutil
import tempfile
import unittest
from pathlib import Path

from devlog.storage import add_entry, get_entries, search_entries
from devlog.summary import generate_summary


class TestDevLog(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.tmp_dir)

    def test_add_and_list_entry(self):
        add_entry(self.tmp_dir, "Fixed login bug", tags=["bugfix"])
        entries = get_entries(self.tmp_dir, days=1)
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0]["message"], "Fixed login bug")
        self.assertIn("bugfix", entries[0]["tags"])

    def test_search_entry(self):
        add_entry(self.tmp_dir, "Refactored auth module", tags=["refactor"])
        add_entry(self.tmp_dir, "Wrote unit tests", tags=["testing"])
        results = search_entries(self.tmp_dir, "auth")
        self.assertEqual(len(results), 1)
        self.assertIn("auth", results[0]["message"].lower())

    def test_summary_generation(self):
        add_entry(self.tmp_dir, "Deployed to production", tags=["deploy"])
        summary = generate_summary(self.tmp_dir, days=1)
        self.assertIn("Deployed to production", summary)
        self.assertIn("#deploy", summary)

    def test_empty_summary(self):
        summary = generate_summary(self.tmp_dir, days=1)
        self.assertIn("No entries found", summary)


if __name__ == "__main__":
    unittest.main()
