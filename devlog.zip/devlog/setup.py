from setuptools import setup, find_packages

setup(
    name="devlog",
    version="0.1.0",
    description="A simple CLI journal/habit tracker for developers.",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "devlog=devlog.cli:main",
        ],
    },
    python_requires=">=3.7",
)
