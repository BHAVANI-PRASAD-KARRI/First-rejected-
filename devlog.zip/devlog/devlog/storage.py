"""
Storage layer: entries are stored as one markdown file per day
inside the log directory, e.g. ~/.devlog/entries/2026-07-16.md
"""
import re
from pathlib import Path
from datetime import datetime, timedelta


def _entry_file(log_dir: Path, date: datetime) -> Path:
    log_dir.mkdir(parents=True, exist_ok=True)
    return log_dir / f"{date.strftime('%Y-%m-%d')}.md"


def add_entry(log_dir: Path, message: str, tags=None):
    tags = tags or []
    now = datetime.now()
    file_path = _entry_file(log_dir, now)
    tag_str = " ".join(f"#{t}" for t in tags)
    line = f"- **{now.strftime('%H:%M')}** {message} {tag_str}".rstrip() + "\n"

    if not file_path.exists():
        file_path.write_text(f"# {now.strftime('%Y-%m-%d')}\n\n", encoding="utf-8")

    with file_path.open("a", encoding="utf-8") as f:
        f.write(line)

    return file_path


def _parse_file(file_path: Path):
    date_str = file_path.stem
    entries = []
    text = file_path.read_text(encoding="utf-8")
    for line in text.splitlines():
        m = re.match(r"- \*\*(\d{2}:\d{2})\*\* (.+)", line)
        if not m:
            continue
        time_str, rest = m.groups()
        tags = re.findall(r"#(\w+)", rest)
        message = re.sub(r"#\w+", "", rest).strip()
        entries.append({
            "date": f"{date_str} {time_str}",
            "message": message,
            "tags": tags,
        })
    return entries


def get_entries(log_dir: Path, days: int = 7):
    if not log_dir.exists():
        return []
    cutoff = datetime.now() - timedelta(days=days)
    all_entries = []
    for file_path in sorted(log_dir.glob("*.md")):
        try:
            file_date = datetime.strptime(file_path.stem, "%Y-%m-%d")
        except ValueError:
            continue
        if file_date.date() >= cutoff.date():
            all_entries.extend(_parse_file(file_path))
    return all_entries


def search_entries(log_dir: Path, query: str):
    if not log_dir.exists():
        return []
    query_lower = query.lower()
    results = []
    for file_path in sorted(log_dir.glob("*.md")):
        for entry in _parse_file(file_path):
            if query_lower in entry["message"].lower() or query_lower in [t.lower() for t in entry["tags"]]:
                results.append(entry)
    return results
