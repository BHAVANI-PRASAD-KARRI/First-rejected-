#!/usr/bin/env python3
"""
DevLog CLI - a simple command-line journal/habit tracker for developers.
"""
import argparse
import sys
from pathlib import Path
from datetime import datetime

from devlog.storage import add_entry, get_entries, search_entries
from devlog.summary import generate_summary

LOG_DIR = Path.home() / ".devlog" / "entries"


def cmd_add(args):
    tags = args.tag if args.tag else []
    entry_path = add_entry(LOG_DIR, args.message, tags)
    print(f"✔ Logged entry -> {entry_path}")


def cmd_list(args):
    entries = get_entries(LOG_DIR, days=args.days)
    if not entries:
        print("No entries found.")
        return
    for entry in entries:
        tag_str = f" [{', '.join(entry['tags'])}]" if entry["tags"] else ""
        print(f"{entry['date']} - {entry['message']}{tag_str}")


def cmd_search(args):
    results = search_entries(LOG_DIR, args.query)
    if not results:
        print(f"No entries matching '{args.query}'.")
        return
    for entry in results:
        print(f"{entry['date']} - {entry['message']}")


def cmd_summary(args):
    summary = generate_summary(LOG_DIR, days=args.days)
    print(summary)
    if args.export:
        out_path = Path(args.export)
        out_path.write_text(summary, encoding="utf-8")
        print(f"\n✔ Summary exported to {out_path}")


def main():
    parser = argparse.ArgumentParser(
        prog="devlog",
        description="A simple CLI journal/habit tracker for developers."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # add
    p_add = subparsers.add_parser("add", help="Add a new log entry")
    p_add.add_argument("message", type=str, help="The log message")
    p_add.add_argument("--tag", action="append", help="Tag for this entry (repeatable)")
    p_add.set_defaults(func=cmd_add)

    # list
    p_list = subparsers.add_parser("list", help="List recent entries")
    p_list.add_argument("--days", type=int, default=7, help="Number of days to show (default: 7)")
    p_list.set_defaults(func=cmd_list)

    # search
    p_search = subparsers.add_parser("search", help="Search entries")
    p_search.add_argument("query", type=str, help="Search term")
    p_search.set_defaults(func=cmd_search)

    # summary
    p_summary = subparsers.add_parser("summary", help="Generate a weekly/period summary")
    p_summary.add_argument("--days", type=int, default=7, help="Number of days to summarize (default: 7)")
    p_summary.add_argument("--export", type=str, help="Export summary to a markdown file")
    p_summary.set_defaults(func=cmd_summary)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
