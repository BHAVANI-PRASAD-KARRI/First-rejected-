"""
Generates a readable weekly/period summary from log entries,
grouped by tag and by day.
"""
from pathlib import Path
from collections import defaultdict
from devlog.storage import get_entries


def generate_summary(log_dir: Path, days: int = 7) -> str:
    entries = get_entries(log_dir, days=days)

    if not entries:
        return f"No entries found in the last {days} day(s)."

    by_day = defaultdict(list)
    by_tag = defaultdict(int)

    for entry in entries:
        day = entry["date"].split(" ")[0]
        by_day[day].append(entry["message"])
        for tag in entry["tags"]:
            by_tag[tag] += 1

    lines = [f"# DevLog Summary — last {days} day(s)\n"]
    lines.append(f"**Total entries:** {len(entries)}\n")

    if by_tag:
        lines.append("## Tag breakdown")
        for tag, count in sorted(by_tag.items(), key=lambda x: -x[1]):
            lines.append(f"- #{tag}: {count}")
        lines.append("")

    lines.append("## Daily log")
    for day in sorted(by_day.keys()):
        lines.append(f"### {day}")
        for msg in by_day[day]:
            lines.append(f"- {msg}")
        lines.append("")

    return "\n".join(lines)
